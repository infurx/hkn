export default function Page(){return (<section><h2 className='text-xl font-bold'>Kreatör Paneli</h2><p>Reklam paketi oluşturma burada.</p></section>)}
