export default function Home(){return (<section><h1 className='text-2xl font-extrabold'>Pazar Yeri</h1><p>Slot listesi burada olacak.</p></section>)}
