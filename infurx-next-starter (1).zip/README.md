
# InfurX — Production Starter

Kurulum:
1) `npm install`
2) `.env.example` -> `.env` kopyala
3) `npm run prisma:push`
4) `npm run dev` ve `http://localhost:3000`

Not: Bu iskelet Next.js + Prisma (SQLite) içindir. Gerçek yayında Postgres'e geçeceğiz.
